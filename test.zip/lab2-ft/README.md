Lab2 Fine-tuning 

